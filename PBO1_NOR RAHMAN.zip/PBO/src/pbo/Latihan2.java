/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo;

/**
 *
 * @author ACER
 */
public class Latihan2 {
       public static void main(String[] args){
        System.out.println("Ini Cuma Print");
        
        System.out.println("Ini Cuman Println");
    }
    
}
