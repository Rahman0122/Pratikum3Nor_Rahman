/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo;

/**
 *
 * @author ACER
 */
public class Latihan4 {
    public static void main(String[] args){
        String sistem_Operasi = "Windows 10", versi = "64 bit",pemilik ="Rahman";
        String sistem_Oprasi = null;
        
        
        System.out.println("Sistem_Oprasi = "+sistem_Oprasi);
        System.out.println("Versi           = "+versi);
        System.out.println("Pemilik         = "+pemilik);
    }
    
}
