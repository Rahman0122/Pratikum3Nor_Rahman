/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo;

/**
 *
 * @author ACER
 */
public class Soal2 {
    public static void main(String[] args){
    
        System.out.println("Nama          : Nor Rahman");
        System.out.println("Program Studi : Teknologi Informasi");
        System.out.println("Nama          : ITs Mandiri dan Teknologi Informasi");
        
    }
}