
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ACER
 */
public class Inputkeyboard2 {
    public static void main(String [] args){
        
    Scanner input = new Scanner(System.in);
    // deklaeasi varianel
       int nilaiA;
       int nilaiB;
       int hasil;
       System.out.println("nilaiA\t:");
       //menampilkan text inputan nilaiA
       nilaiA = input.nextInt();
       //menyimpan inputan nilaiA
       
       System.out.print("nilaiB\t:");
       //menampikan inputan nilaiB
       nilaiB = input.nextInt(); 
       //menyimpan inputan nilaiB
       hasil = nilaiA + nilaiB;
       System.out.println("\nMenampilkan Hasil:");
       System.out.println("nilaiA + nilaiB = "+hasil);
     
    }
}
