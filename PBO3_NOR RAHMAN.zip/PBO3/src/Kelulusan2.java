
import java.util.Scanner;
/**
 *
 * @author ACER
 */
public class Kelulusan2 {
    public static void main(String[] args) {
        // Buat Scanner
        Scanner inp = new Scanner(System.in);
        // Ambil Nama
        System.out.print("Masukkan nama anda = ");
        String Nama = inp.next();

        // Ambil Jenis Kelamin
        System.out.print("Jenis Kelamin = ");
        String jenis_kelamin = inp.next();
        
        // Ambil Tinggi Badan
        System.out.print("Tinggi Badan = ");
        int tinggi_badan = inp.nextInt();
        // print
     if("laki-laki".equals(jenis_kelamin)) {
        if(tinggi_badan >= 170) {
             System.out.println("Selamat Anda Lulus");
        }else {
             System.out.println("Anda Gagal");
        }
        } else if("perempuan".equals(jenis_kelamin)) {
          if(tinggi_badan >= 160) { 
             System.out.println("Selamat Anda Lulus");
        }else {
             System.out.println("Anda Gagal");
        }
    }
}
}
