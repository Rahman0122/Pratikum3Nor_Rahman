
import java.util.Scanner;
/**
 *
 * @author ACER
 */
public class NilaiHuruf {
     public static void main(String[] args) {
        // Buat Scanner
        Scanner inp = new Scanner(System.in);
        // Ambil Nama
        System.out.print("Masukkan nama anda = ");
        String Nama = inp.next();

        // Ambil NIM
        System.out.print("Masukkan  NIM = ");
        String nim = inp.next();

        // Ambil Nilai
        System.out.print("Masukkan Nilai = ");
        int nilai = inp.nextInt();
        // print
        if (nilai <= 0){
             System.out.println("Error");
        }else if(nilai <= 55) {
             System.out.println("E");
        }else if (nilai <= 65){
             System.out.println("D");
        }else if (nilai <= 75){
             System.out.println("C");
        }else if (nilai <= 85){
             System.out.println("B");
        }else if (nilai <= 100){
             System.out.println("A");
        }
    }
}
