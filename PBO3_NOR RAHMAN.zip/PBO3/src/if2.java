
import java.util.Scanner;
/**
 *
 * @author ACER
 */
public class if2 {
    public static void main(String[] args) {
        // Buat scanner
        Scanner s1 = new Scanner(System.in);
        // Ambil nilai dari keyboard
        System.out.print("Masukkan nilai1 = ");
        int nilai1 = s1.nextInt();
        System.out.print("Masukkan nilai2 = ");  
        int nilai2 = s1.nextInt();
        System.out.print("Masukkan nilai3 = ");
        int nilai3 = s1.nextInt();
        
        if (nilai1 > nilai2 && nilai1 > nilai3){
            System.out.println("Nilai Terbesar Adalah Nilai 1 = "+nilai1);
        }else if (nilai1 > nilai2 && nilai2 > nilai3)  {
            System.out.println("Nilai Terbesar Adalah Nilai 2 = "+nilai2);
        }else {
            System.out.println("Nilai Terbesar Adalah Nilai 3 = "+nilai3);
        }
    }
}
