
/**
 *
 * @author a
 */
public class Latihan1 {
    public static void main(String[] args ){
        int angka_sistem = 100;
        
        if(angka_sistem < 150) {
            System.out.println("Ini Merupakan Statement if");
        }
        System.out.println("Program Selasai");
    }
    
}
