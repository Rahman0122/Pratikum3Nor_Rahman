
import java.util.Scanner;
/**
 *
 * @author a
 */
public class Latihan2 {
    public static void main(String [] args){
         int Belanja = 0;
         Scanner scan = new Scanner(System.in).useDelimiter("\n");
         System.out.print("Total Belanja : Rp");
         Belanja = scan.nextInt();
         if (Belanja > 100000){
             System.out.println("Selamat, anda mendapatkan diskon !");
         } 
         System.out.println("Terima Kasih");
    }
}