
import java.util.Scanner;
/**
 *
 * @author a
 */
public class Latihan4 {
    public static void main (String [] args ){
        Scanner scan = new Scanner(System.in).useDelimiter("\n");
        System.out.println("Apakah anda mahasiswa Poliban ? (Y jika setuju)");
        String jawaban = scan.next();
        if ("Y".equals(jawaban)){
            System.out.println("Selamat Berjuang di Poliban");
        }else{
            System.out.println("Selamat Datang Di Poliban");
        }
    }
}
