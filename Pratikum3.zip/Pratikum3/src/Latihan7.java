
import java.util.Scanner;

public class Latihan7 {
    public static void main(String [] args){
        Scanner scan = new Scanner(System.in).useDelimiter("\n");
        System.out.println("Siapakah presiden Pertama Indonesia ?");
        System.out.println("a.Dr.Ir.H.Soekarno");
        System.out.println("a.B.J. Habibie");
        System.out.println("c.Megawati Seokarno Putri");
        System.out.println("d.Abdurrahman Wahid");
        char pilih =scan.next().charAt(0);
        
        switch(pilih){
            case 'a':
                System.out.println("Benar !");
            break;
            case 'b':
                System.out.println("Salah,jawabannya adalah Dr.Ir.H.Soekarno");
                break;
            case 'c' :
                System.out.println("Salah,jawabannya adalah Dr.Ir.H.Soekarno");
                break;
            case 'd' :
                System.out.println("Salah,jawabannya adalah Dr.Ir.H.Soekarno");
                break;
            default :
                System.out.println("Sistem Error");
        }
    }
}
