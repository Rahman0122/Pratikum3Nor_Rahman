
public class Soal1 {
    public static void main(String [] args){
        double d = 1.2345;
        short s = (short) d;
        
        System.out.println("Nilai d =" +d);
        System.out.println("Nilai s =" +s);
       
    }
}
